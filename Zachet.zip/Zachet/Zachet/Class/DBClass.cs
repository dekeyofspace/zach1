﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zachet.DataBase
{ 
    /// <summary>
    /// класс базы данных
    /// </summary>
    class DBClass
    {
        public static lolEntities modelEnt;
    }
}
