﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Zachet.DataBase;

namespace Zachet.Class
{

    public class FunctionalClass : IFuctionalAddMark
    {
        public int IdRole { get; set; }

        public FunctionalClass(int IdRoleUser)
        {
            IdRole = IdRoleUser;
        }

        public void AddMark(int MarkUser, int IdStudent, int groupUser, int disciplineUser)
        {
            if ((MarkUser >= 2) && (MarkUser <= 5))
            //Образец  объекта
            {
                Mark newMark = new Mark
                {
                    idGroup = groupUser,
                    idStudent = IdStudent,
                    idDiscipline = disciplineUser,
                    Marks = MarkUser
                };
                //Добавляет данные в базу данных
                DBClass.modelEnt.Mark.Add(newMark);
                //Сохраняет данные в базу данных
                DBClass.modelEnt.SaveChanges();
                MessageBox.Show("Оценка добавлена", "Успешно");
            }
            else
            {
                MessageBox.Show("Оценка добавлена", "Успешно");               
            }
        }

        public string ViewInfo()
        {
            throw new NotImplementedException();
        }
    }
}