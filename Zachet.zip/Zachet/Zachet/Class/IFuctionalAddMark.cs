﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zachet.Class
{
    public interface IFuctionalAddMark
    {
        /// <summary>
        /// Добавление оценки
        /// </summary>
        /// <param name="MarkUser"> Оценка </param>
        /// <param name="groupUser"> Id Группы </param>
        /// <param name="student"> Id Студента </param>
        /// <param name="disciplineUser"> Id Дисциплины </param>
        /// <returns>Результат добавил / не добавил оценку</returns>
        void AddMark(int MarkUser, int IdStudent, int groupUser, int disciplineUser);
        string ViewInfo();
    }
}
