﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zachet.DataBase
{
    /// <summary>
    /// класс хранения оценок одного выбранного студента
    /// </summary>
    class StudentClass
    {
        public static string Student { get; set; }
    }
}
