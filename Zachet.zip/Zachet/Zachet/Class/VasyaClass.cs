﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zachet.Class
{
    class VasyaClass : IFuctionalAddMark
    {
        public void AddMark(int MarkUser, int IdStudent, int groupUser, int disciplineUser)
        {
            throw new NotImplementedException();
        }

        public string ViewInfo()
        {
            throw new NotImplementedException();
        }
    }
}
