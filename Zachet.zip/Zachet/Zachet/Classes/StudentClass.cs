﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zachet.DataBase
{
    class StudentClass
    {
        public static string st { get; set; }
    }
}
