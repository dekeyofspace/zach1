﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zachet.Class;
using Zachet.DataBase;

namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для AddMark.xaml
    /// </summary>
    public partial class AddMark : Page
    {
        public AddMark()
        {
            InitializeComponent();
            //Добвление данных в комбобокс 
            CmbStudent.SelectedValuePath = "id";
            CmbStudent.DisplayMemberPath = "FullName";
            CmbStudent.ItemsSource = DBClass.modelEnt.Student.ToList();

            CmbGroup.SelectedValuePath = "id";
            CmbGroup.DisplayMemberPath = "NameGroup";
            CmbGroup.ItemsSource = DBClass.modelEnt.Group.ToList();

            CmbDiscipline.SelectedValuePath = "id";
            CmbDiscipline.DisplayMemberPath = "NameDiscipline";
            CmbDiscipline.ItemsSource = DBClass.modelEnt.Discipline.ToList();

        }

        private void BtAddMark_Click(object sender, RoutedEventArgs e)
        {
            int role = 4;
            FunctionalClass functionalClass = new FunctionalClass(role);
            switch (role)
            {
                case 1: 
                    functionalClass.AddMark(Convert.ToInt32(tbMarks.Text), (int)CmbStudent.SelectedValue, (int)CmbGroup.SelectedValue, (int)CmbDiscipline.SelectedValue);
                    break;
                case 2: 
                    functionalClass.AddMark(Convert.ToInt32(tbMarks.Text), (int)CmbStudent.SelectedValue, (int)CmbGroup.SelectedValue, (int)CmbDiscipline.SelectedValue);
                    break;
                default:
                    break;
            }

        }
        
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Добавление сортированных данных из Базы Данных в комбобокс
            CmbStudent.ItemsSource = DBClass.modelEnt.Student.Where(x => x.idGroup == (int)CmbGroup.SelectedValue).ToList();
        }
        //Переход к Главной странице
        private void BtGoBack_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new HomePage());
        }

    }
}
