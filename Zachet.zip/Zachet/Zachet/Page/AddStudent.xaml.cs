﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zachet.DataBase;

namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для AddStudent.xaml
    /// </summary>
    public partial class AddStudent : Page
    {
        public AddStudent()
        {
            InitializeComponent();

            //Добвление данных в комбобокс 
            CmbNameGroup.SelectedValuePath = "id";
            CmbNameGroup.DisplayMemberPath = "NameGroup";
            CmbNameGroup.ItemsSource = DBClass.modelEnt.Group.ToList();

            CmbSpeciality.SelectedValuePath = "id";
            CmbSpeciality.DisplayMemberPath = "NameSpeciality";
            CmbSpeciality.ItemsSource = DBClass.modelEnt.Speciality.ToList();

            CmbForm.SelectedValuePath = "id";
            CmbForm.DisplayMemberPath = "NameForm";
            CmbForm.ItemsSource = DBClass.modelEnt.Form.ToList();

        }

        private void BtnAddStudent_Click(object sender, RoutedEventArgs e)
        {
            //Образец  объекта
            Student studentobj = new Student()

            {
                FullName = tbFullName.Text,
                Speciality = CmbSpeciality.SelectedItem as Speciality,
                Date = Date.SelectedDate,
                Form = CmbForm.SelectedItem as Form,
                Group = CmbNameGroup.SelectedItem as Group,
            };

            //Добавляет данные в базу данных
            DBClass.modelEnt.Student.Add(studentobj);
            //Сохраняет данные в базу данных
            DBClass.modelEnt.SaveChanges();
            MessageBox.Show("Студент добавлен!", "Студент", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        
        private void BtnGoBack_Click(object sender, RoutedEventArgs e)
        {
            //Переход к Главной странице
            FrameClass.frm.Navigate(new HomePage());
        }
    }
}
