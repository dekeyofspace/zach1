﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для start.xaml
    /// </summary>
    public partial class HomePage : Page
    {
        public HomePage()
        {
            InitializeComponent();
        }


        //Переход на страницу списка студентов
        private void BtnAddStudents_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new AddStudent());
        }

        //Переход на страницу добавления оценок
        private void BtnAddMarks_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new AddMark());
        }
        //Переход на страницу добавления студентов
        private void BtnStudentsView_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new ListPage());
        }
    }
}
