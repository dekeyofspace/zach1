﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zachet.DataBase;

namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для spisok.xaml
    /// </summary>
    public partial class ListPage : Page
    {
        public ListPage()
        {
            InitializeComponent();
            //Заполнение ListView
            ViewStudents.ItemsSource = DBClass.modelEnt.Student.ToList();
            //Заполнение комбобокса
            CmbSearchGroup.SelectedValuePath = "id";
            CmbSearchGroup.DisplayMemberPath = "NameGroup";
            CmbSearchGroup.ItemsSource = DBClass.modelEnt.Group.ToList();
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { 
            //Динамический объект равен выбранному элементу из списка
            dynamic selectedStudent = ViewStudents.SelectedItems[0];
            //Запоминаем выбранного студента
            StudentClass.Student = selectedStudent.FullName;
            FrameClass.frm.Navigate(new MarksPage()); 
        }

        private void BtnGoBack_Click(object sender, RoutedEventArgs e)
        {
            //Переход к Главной странице
            FrameClass.frm.Navigate(new HomePage());
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            //Заполнение ListView с сортировкой, учитывая выбранную группу
            ViewStudents.ItemsSource = DBClass.modelEnt.Student.Where(x => x.idGroup == (int)CmbSearchGroup.SelectedValue).ToList();
        }
    }
}
