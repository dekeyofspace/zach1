﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zachet.DataBase;

namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для marks.xaml
    /// </summary>
    public partial class MarksPage : Page
    {
        public MarksPage()
        {
            InitializeComponent();
            //Заполнение списка оценок по выбранному студенту
            ViewMarks.ItemsSource = DBClass.modelEnt.Mark.Where(x => x.Student.FullName == StudentClass.Student).ToList();
        }

        private void BtnGoBack_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new ListPage());
        }
    }
}
