﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zachet.DataBase;


namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для AddMark.xaml
    /// </summary>
    public partial class AddMark : Page
    {
        public AddMark()
        {
            InitializeComponent();
            combo2.SelectedValuePath = "id";
            combo2.DisplayMemberPath = "FullName";
            combo2.ItemsSource = DBClass.modelEnt.Student.ToList();

            combo1.SelectedValuePath = "id";
            combo1.DisplayMemberPath = "NameGroup";
            combo1.ItemsSource = DBClass.modelEnt.Group.ToList();

            combo3.SelectedValuePath = "id";
            combo3.DisplayMemberPath = "NameDiscipline";
            combo3.ItemsSource = DBClass.modelEnt.Discipline.ToList();

        }

        private void txb1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Mark newMark = new Mark
            {
                idGroup = (int)combo1.SelectedValue,
                idStudent = (int)combo2.SelectedValue,
                idDiscipline = (int) combo3.SelectedValue,
                Marks = Int32.Parse(tb1.Text)
            };
            DBClass.modelEnt.Mark.Add(newMark);
            DBClass.modelEnt.SaveChanges();
            MessageBox.Show("Успех", "Оценка добавлена", MessageBoxButton.OK);
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            combo2.ItemsSource = DBClass.modelEnt.Student.Where(x => x.idGroup == (int)combo1.SelectedValue).ToList();
        }

        private void Bt2_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void Bt4_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new HomePage());
        }
    }
}
