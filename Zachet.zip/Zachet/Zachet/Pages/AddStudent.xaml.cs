﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zachet.DataBase;

namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для AddStudent.xaml
    /// </summary>
    public partial class AddStudent : Page
    {
        public AddStudent()
        {
            InitializeComponent();

            cb4.SelectedValuePath = "id";
            cb4.DisplayMemberPath = "NameGroup";
            cb4.ItemsSource = DBClass.modelEnt.Group.ToList();

            cb1.SelectedValuePath = "id";
            cb1.DisplayMemberPath = "NameSpeciality";
            cb1.ItemsSource = DBClass.modelEnt.Speciality.ToList();

            cb3.SelectedValuePath = "id";
            cb3.DisplayMemberPath = "NameForm";
            cb3.ItemsSource = DBClass.modelEnt.Form.ToList();

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Student studentobj = new Student()

            {

                FullName = txb1.Text,
                Speciality = cb1.SelectedItem as Speciality,
                Date = DT.SelectedDate,
                Form = cb3.SelectedItem as Form,
                Group = cb4.SelectedItem as Group,
            };

            DBClass.modelEnt.Student.Add(studentobj);
            DBClass.modelEnt.SaveChanges();
            MessageBox.Show("Студент добавлен!", "Студент", MessageBoxButton.OK, MessageBoxImage.Information);

        
        }

      

        private void cb4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Bt3_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new HomePage());
        }
    }
}
