﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zachet.DataBase;

namespace Zachet
{
    /// <summary>
    /// Логика взаимодействия для spisok.xaml
    /// </summary>
    public partial class spisok : Page
    {
        public spisok()
        {
            InitializeComponent();
            LV1.ItemsSource = DBClass.modelEnt.Student.ToList();
            comb1.SelectedValuePath = "id";
            comb1.DisplayMemberPath = "NameGroup";
            comb1.ItemsSource = DBClass.modelEnt.Group.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LV1.ItemsSource = DBClass.modelEnt.Student.Where(x => x.idGroup == (int)comb1.SelectedValue).ToList();
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dynamic selectedStudent = LV1.SelectedItems[0];
            StudentClass.st = selectedStudent.FullName;
            FrameClass.frm.Navigate(new MarksPage()); 
        }

        private void comb1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Bt2_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.frm.Navigate(new HomePage());
        }
    }
}
